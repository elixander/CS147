<form action="login.php" method="post">
	<label for="foo">Username:</label>
	<input type="text" name="username" id="foo">
	<label for="bar">Password:</label>
	<input type="password" name="password" id="bar">
	<input type="submit" value="Login">
</form>

<script src="https://gist.github.com/3937498.js?file=index.php"></script>